#include"table.h"
using namespace std;

int main() {
   
    cin.tie(NULL);

    int N, Q;
    cin >> N >> Q;

    OuterHashTable outer_table(N);

    for (int _ = 0; _ < Q; _++) {
        string cmd; 
        cin >> cmd;

        if (cmd == "INSERT") {
            int group_id, user_id;
            string permission;
            cin >> group_id >> user_id >> permission;
            outer_table.insert(group_id, user_id, permission);
        }
        else if (cmd == "SEARCH") {
            int group_id; 
            cin >> group_id;
            string next;
            
        }
        else if (cmd == "DELETE") {
            int group_id, user_id;
            cin >> group_id >> user_id;
            bool found;
            pair<int, string> res = outer_table.remove(group_id, user_id, found);
            if (!found) {
                cout << "User not found in group " << group_id << "\n";
            } else {
                cout << "(" << res.first << ", " << res.second << ") deleted\n";
            }
        }
    }

    return 0;
}
